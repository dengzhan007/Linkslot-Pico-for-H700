Read-only MMC mapping capture completed.
Output directory: /tmp/h700-mmc-map-r2
No block-device read/write command was issued by this collector.
All captured MMC CID/CSD identity fields are intentionally omitted.
